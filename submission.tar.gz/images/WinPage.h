/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 WinPage Winpage.jpg 
 * Time-stamp: Tuesday 04/04/2023, 16:19:52
 * 
 * Image Information
 * -----------------
 * Winpage.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WINPAGE_H
#define WINPAGE_H

extern const unsigned short Winpage[38400];
#define WINPAGE_SIZE 76800
#define WINPAGE_LENGTH 38400
#define WINPAGE_WIDTH 240
#define WINPAGE_HEIGHT 160

#endif

