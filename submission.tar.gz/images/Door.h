/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=40x40 Door Door.jpeg 
 * Time-stamp: Tuesday 04/04/2023, 18:44:10
 * 
 * Image Information
 * -----------------
 * Door.jpeg 40@40
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DOOR_H
#define DOOR_H

extern const unsigned short Door[1600];
#define DOOR_SIZE 3200
#define DOOR_LENGTH 1600
#define DOOR_WIDTH 40
#define DOOR_HEIGHT 40

#endif

