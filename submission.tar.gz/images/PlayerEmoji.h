/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 PlayerEmoji PlayerEmoji.jpg 
 * Time-stamp: Tuesday 04/04/2023, 17:48:50
 * 
 * Image Information
 * -----------------
 * PlayerEmoji.jpg 72@72
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PLAYEREMOJI_H
#define PLAYEREMOJI_H

extern const unsigned short PlayerEmoji[5184];
#define PLAYEREMOJI_SIZE 10368
#define PLAYEREMOJI_LENGTH 5184
#define PLAYEREMOJI_WIDTH 72
#define PLAYEREMOJI_HEIGHT 72

#endif

