/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=15x15 EmojiPlayer EmojiPlayer.jpeg 
 * Time-stamp: Tuesday 04/04/2023, 17:52:55
 * 
 * Image Information
 * -----------------
 * EmojiPlayer.jpeg 15@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef EMOJIPLAYER_H
#define EMOJIPLAYER_H

extern const unsigned short EmojiPlayer[225];
#define EMOJIPLAYER_SIZE 450
#define EMOJIPLAYER_LENGTH 225
#define EMOJIPLAYER_WIDTH 15
#define EMOJIPLAYER_HEIGHT 15

#endif

