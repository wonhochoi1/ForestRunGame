/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 StartPage ForestRunPage.png 
 * Time-stamp: Tuesday 04/04/2023, 16:16:28
 * 
 * Image Information
 * -----------------
 * ForestRunPage.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef STARTPAGE_H
#define STARTPAGE_H

extern const unsigned short ForestRunPage[38400];
#define FORESTRUNPAGE_SIZE 76800
#define FORESTRUNPAGE_LENGTH 38400
#define FORESTRUNPAGE_WIDTH 240
#define FORESTRUNPAGE_HEIGHT 160

#endif

