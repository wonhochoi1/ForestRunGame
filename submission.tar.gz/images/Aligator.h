/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=30x70 Aligator Aligator.jpeg 
 * Time-stamp: Tuesday 04/04/2023, 19:24:23
 * 
 * Image Information
 * -----------------
 * Aligator.jpeg 30@70
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ALIGATOR_H
#define ALIGATOR_H

extern const unsigned short Aligator[2100];
#define ALIGATOR_SIZE 4200
#define ALIGATOR_LENGTH 2100
#define ALIGATOR_WIDTH 30
#define ALIGATOR_HEIGHT 70

#endif

