/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize 30x50 TREE TREE.png 
 * Time-stamp: Tuesday 04/04/2023, 19:25:01
 * 
 * Image Information
 * -----------------
 * TREE.png 30@50
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TREE_H
#define TREE_H

extern const unsigned short TREE[1500];
#define TREE_SIZE 3000
#define TREE_LENGTH 1500
#define TREE_WIDTH 30
#define TREE_HEIGHT 50

#endif

