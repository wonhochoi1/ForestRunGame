/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 LosePage LosePage.jpg 
 * Time-stamp: Tuesday 04/04/2023, 16:20:35
 * 
 * Image Information
 * -----------------
 * LosePage.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef LOSEPAGE_H
#define LOSEPAGE_H

extern const unsigned short LosePage[38400];
#define LOSEPAGE_SIZE 76800
#define LOSEPAGE_LENGTH 38400
#define LOSEPAGE_WIDTH 240
#define LOSEPAGE_HEIGHT 160

#endif

